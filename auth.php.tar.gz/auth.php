<?php
require 'send_email.php';

$servername = "localhost";
$username = "dynastyhosting_social"; // Change this to your MySQL username
$password = "d9Au7MmbqBJh5ucSz2kq"; // Change this to your MySQL password
$dbname = "dynastyhosting_social";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $action = $_POST['action'];
    $username = $_POST['username'];
    $password = $_POST['password'];

    if ($action == 'register') {
        $confirm_password = $_POST['confirm_password'];
        if ($password != $confirm_password) {
            echo "Passwords do not match!";
            exit;
        }

        $hashed_password = password_hash($password, PASSWORD_DEFAULT);
        $sql = "INSERT INTO users (username, password) VALUES ('$username', '$hashed_password')";

        if ($conn->query($sql) === TRUE) {
            echo "Registration successful!";
            // Send welcome email
            $to = $username; // Assuming the username is the email address
            $subject = "Welcome to TikTok Clone!";
            $body = "Thank you for registering with TikTok Clone. Enjoy our service!";
            sendEmail($to, $subject, $body);
        } else {
            echo "Error: " . $sql . "<br>" . $conn->error;
        }
    } elseif ($action == 'login') {
        $sql = "SELECT * FROM users WHERE username='$username'";
        $result = $conn->query($sql);

        if ($result->num_rows > 0) {
            $row = $result->fetch_assoc();
            if (password_verify($password, $row['password'])) {
                echo "Login successful!";
                // Send login notification email
                $to = $username; // Assuming the username is the email address
                $subject = "Login Notification";
                $body = "You have successfully logged in to TikTok Clone.";
                sendEmail($to, $subject, $body);
            } else {
                echo "Invalid password!";
            }
        } else {
            echo "No user found with that username!";
        }
    }
}

$conn->close();
?>